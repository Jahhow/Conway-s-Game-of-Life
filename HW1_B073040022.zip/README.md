# Conway's Game of Life
[Preview](https://htmlpreview.github.io/?https://github.com/Jahhow/Conway-s-Game-of-Life/blob/master/conway%27s%20game%20of%20life.html)

- Random initialization
- Click on a cell to flip its state.
- Supports window resizing and fullscreen mode
- Colorful cells